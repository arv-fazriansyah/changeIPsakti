#!/system/bin/sh
/system/bin/sh /system/bin/changeIPsakti.sh